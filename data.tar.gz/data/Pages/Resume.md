# Resume

## Work Experience

### ITM8 A/S
***September 19th, 2022 - NOW (January 31st, 2025)***

Development and maintenance of internal enterprise system for ITSM among other things.
The system is composed of multiple isolated micro-services primarily hosted in a 
Kubernetes cluster on Azure. The front-end is a Blazor server application. 

Technologies I used were .net 8, EF Core, SQL Server, xUnit, Test Containers. 
Tools and environments were Visual Studio 2022, Azure Cloud services, Kubernetes 
and Azure DevOps with Git.

Unfortunately, I was let go along with some 60 other people, due to company re-organisation. 

### BITPEOPLE A/S
***DECEMBER 1st, 2020 – SEPTEMBER 1st, 2022***

Development and maintenance of both small and large customer solutions for SAP Business One. 
Technologies used were COM, SOAP and REST services using .NET Framework 4.5+, Sql Server and 
xUnit for testing. Tools and environments were Visual Studio 2019 and Azure DevOps server 
with TFVC. 

I chose to quit my position, as I was offered other work through a former colleague. 

### ZEEDS APS 
***APRIL 20th, 2020 – JULY 31st, 2020***

Development and maintenance primarily of the back-end for the now defunct web-portal https://pengeprofilen.dk. 
Technologies used were .net core 2.2, SQL Server Azure. The portal was hosted in Azure cloud. 

I was let go due to the company had overreached, and didn't have enough tasks for me. 

### BOYUM IT A/S
***JANUAR 1st, 2020 – MARCH 31st, 2020***

Development and maintenance of both small and large customer solutions for SAP Business One. 
Technologies used were COM, SOAP and REST services using .NET Framework 4.5+, Sql Server and 
xUnit for testing. Tools and environments were Visual Studio 2019 and Azure DevOps server 
with TFVC. 

I was let go within my trial period due to the emergence of the Corona crisis. 

### SCANVAEGT SYSTEMS A/S
***MAY 1st, 2000 – DECEMBER 31st, 2019***
Started originally with Delphi 4 (later 6) on the main product ScanX, and took over
the technical lead on this in 2004. I was was appointed system architect and lead
developer on the successor ScanX.NET in 2009. 
Tasks were many, from architecture, development, testing and maintaining the flagship
software ScanX.NET for heavy-duty weighing. 
Primarily technologies used where .NET 3.5 (later 4.5 and newer) with C#, Winforms, WCF and SQL Server. 

After nearly 20 years I needed new challenges and quit my position. 

### Others (Unskilled, Student job, etc.)
* **SCANTEXT A/S** (1998 – 1999) - Student job, miscellaneous.
* **BILKA TILST** (1994 – 1996) - Unskilled cleaning after hours. 
* **PALSGAARD TRÆINDUSTRI** (1991 – 1992) - Unskilled worker at saw mill. 
* **STATOIL** (1988 – 1991) - Student Job, minding the gas station.

## Education

* Certified as *Systems architect, Practitioner* at Teknologisk Institut in Aarhus (2018).
* Certified as *IT-Architect, Foundation* at Teknologisk Institut in Aarhus(2017).
* *Academy Profession Degree in Computer Science* at Aarhus School of Business (2000).
* Data Science at Aarhus University from 1992 – 1994. Dropped out due to the math level.
* Matematical line at Tørring Amtsgymnasium. 1988 – 1991
* Folkeskole inkl. 10. klasse. 1978 – 1988

## Proficiencies
During my years I have gained various levels of proficiency with many software products, development techniques, etc. 
I have assigned a general rating to each item, which include but are not limited to: 

* **Software Products**
  * 4/5 - Microsoft Windows
  * 4/5 - Microsoft SQL Server
  * 4/5 - Visual Studio
  * 3/5 - Git
  * 3/5 - Microsoft Office (Word, Excel)
  * 2/5 - Subversion
  * 3/5 - Azure DevOps
  * 2/5 - Azure Cloud
* **Skills**  
  * 5/5 - Software design
  * 4/5 - Database design
  * 4/5 - Design Patterns
  * 4/5 - Software Test
* **Development Technologies**
  * 5/5 - C#
  * 4/5 - T-SQL
  * 4/5 - XML and JSON
  * 4/5 - Linq
  * 3/5 - Powershell
  * 3/5 - HTML and CSS
  * 2/5 - Javascript 
  * 2/5 - Blazor
  * 2/5 - Vue.js

## Personality Cues
Creative, Independent, Goal-oriented, Imaginative, Meticulous, Purposeful, Humorous. 